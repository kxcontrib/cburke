#!/bin/bash
# example start q

cd ~/q
if [ "x86_64" == `uname -m` ]; then p=l64; else p=l32; fi
rlwrap $p/q "$@"

